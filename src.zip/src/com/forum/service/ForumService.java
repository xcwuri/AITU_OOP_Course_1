package service;

import domain.Answer;
import domain.Question;
import domain.User;
import repository.QuestionRepository;

public class ForumService {
    private final QuestionRepository questionRepo; // Dependency Injection

    public ForumService(QuestionRepository questionRepo) {
        this.questionRepo = questionRepo;
    }

    public void postQuestion(Question question) {
        questionRepo.save(question);
    }

    public void addAnswer(int questionId, Answer answer) {
        Question q = questionRepo.findById(questionId);
        if (q != null) {
            q.addAnswer(answer); // Logic for composition [cite: 39]
        }
    }

    public void acceptAnswer(Answer answer) {
        answer.setAccepted(true);
        // Business logic: Increase author reputation [cite: 104]
        User author = answer.getAuthor();
        author.setReputation(author.getReputation() + 10);
    }
}