package service;

import domain.Moderator;
import domain.User;
import repository.QuestionRepository;

public class ModerationService {
    private final QuestionRepository questionRepo;

    public ModerationService(QuestionRepository questionRepo) {
        this.questionRepo = questionRepo;
    }

    public void deleteSpam(User user, int questionId) {
        // Business logic: Role check [cite: 104]
        if (user instanceof Moderator) {
            questionRepo.delete(questionId);
            System.out.println("Moderator deleted spam.");
        } else {
            System.out.println("Access denied: Regular users cannot delete posts.");
        }
    }
}