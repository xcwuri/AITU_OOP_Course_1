package repository;

import domain.Question;
import java.util.List;

public interface QuestionRepository {
    void save(Question question);
    Question findById(int id);
    List<Question> findAll();
    void delete(int id); // Part of CRUD requirements [cite: 99]
}