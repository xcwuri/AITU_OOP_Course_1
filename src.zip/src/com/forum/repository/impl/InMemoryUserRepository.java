package repository.impl;

import domain.User;
import repository.UserRepository;
import java.util.ArrayList;
import java.util.List;

public class InMemoryUserRepository implements UserRepository {
    // Data stored in Java collections as required [cite: 12, 51]
    private final List<User> users = new ArrayList<>();

    @Override
    public void save(User user) {
        users.add(user);
    }

    @Override
    public User findById(int id) {
        return users.stream()
                .filter(u -> u.getId() == id)
                .findFirst()
                .orElse(null);
    }

    @Override
    public List<User> findAll() {
        return new ArrayList<>(users);
    }
}