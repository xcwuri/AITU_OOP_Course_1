package repository.impl;

import domain.Question;
import repository.QuestionRepository;
import java.util.ArrayList;
import java.util.List;

public class InMemoryQuestionRepository implements QuestionRepository {
    private final List<Question> questions = new ArrayList<>();

    @Override
    public void save(Question question) {
        questions.add(question);
    }

    @Override
    public Question findById(int id) {
        return questions.stream()
                .filter(q -> q.getId() == id)
                .findFirst()
                .orElse(null);
    }

    @Override
    public List<Question> findAll() {
        return new ArrayList<>(questions);
    }

    @Override
    public void delete(int id) {
        questions.removeIf(q -> q.getId() == id);
    }
}