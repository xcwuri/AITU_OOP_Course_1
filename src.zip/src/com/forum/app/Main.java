package app;

import domain.*;
import repository.QuestionRepository;
import repository.UserRepository;
import repository.impl.InMemoryQuestionRepository;
import repository.impl.InMemoryUserRepository;
import service.ForumService;
import service.ModerationService;

public class Main {
    public static void main(String[] args) {
        // 1. Initialize Repositories (Data Layer)
        UserRepository userRepo = new InMemoryUserRepository();
        QuestionRepository questionRepo = new InMemoryQuestionRepository();

        // 2. Initialize Services (Business Layer)
        ForumService forumService = new ForumService(questionRepo);
        ModerationService moderationService = new ModerationService(questionRepo);

        // 3. Demo: Create Users (Regular and Moderator)
        RegularUser user = new RegularUser(1, "Alice");
        Moderator mod = new Moderator(2, "Bob");
        userRepo.save(user);
        userRepo.save(mod);

        // 4. CRUD: Create - Post a Question
        Question q1 = new Question(101, "How to use SOLID in Java?", user);
        forumService.postQuestion(q1);
        System.out.println("Question Posted: " + q1.getTitle() + " by " + user.getName());

        // 5. CRUD: Update - Add an Answer
        Answer a1 = new Answer(201, "Use interfaces for DIP.", mod);
        forumService.addAnswer(101, a1);
        System.out.println("Answer added to Question 101.");

        // 6. Business Operation: Accept Answer (Updates reputation)
        forumService.acceptAnswer(a1);
        System.out.println("Answer accepted. " + mod.getName() + " Reputation: " + mod.getReputation());

        // 7. CRUD: Read - List all questions
        System.out.println("\n--- Current Forum Questions ---");
        questionRepo.findAll().forEach(q -> System.out.println(q.getId() + ": " + q.getTitle()));

        // 8. CRUD: Delete - Moderation logic
        System.out.println("\n--- Testing Moderation ---");
        moderationService.deleteSpam(user, 101); // Should fail (Regular User)
        moderationService.deleteSpam(mod, 101);  // Should succeed (Moderator)

        // 9. Read: Final Check
        System.out.println("Questions remaining: " + questionRepo.findAll().size());
    }
}