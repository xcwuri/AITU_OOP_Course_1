package domain;

// Abstract class  with private fields [cite: 41]
public abstract class User {
    private int id;
    private String name;
    private int reputation;

    public User(int id, String name) {
        this.id = id;
        this.name = name;
        this.reputation = 0;
    }

    // Access via get/set [cite: 42]
    public int getId() { return id; }
    public String getName() { return name; }
    public int getReputation() { return reputation; }
    public void setReputation(int reputation) { this.reputation = reputation; }
}