package domain;

public class Answer {
    private int id;
    private String text;
    private User author;
    private int votes;
    private boolean accepted;

    public Answer(int id, String text, User author) {
        this.id = id;
        this.text = text;
        this.author = author;
    }

    public int getVotes() { return votes; }
    public void setVotes(int votes) { this.votes = votes; }
    public boolean isAccepted() { return accepted; }
    public void setAccepted(boolean accepted) { this.accepted = accepted; }
    public String getText() { return text; }
}